const toggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
if (toggle && nav) {
  toggle.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
  });
  nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    nav.classList.remove('open');
    toggle.setAttribute('aria-expanded', 'false');
    toggle.setAttribute('aria-label', 'Open navigation');
  }));
}
document.getElementById('year').textContent = new Date().getFullYear();
const form = document.getElementById('interest-form');
if (form) {
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    document.getElementById('form-message').textContent =
      'Thank you for your interest! This demo form is not connected yet, so your message has not been sent. Please connect a form service before publishing.';
  });
}
